def main() -> None:
    print("Hello from nsc325-group1!")
